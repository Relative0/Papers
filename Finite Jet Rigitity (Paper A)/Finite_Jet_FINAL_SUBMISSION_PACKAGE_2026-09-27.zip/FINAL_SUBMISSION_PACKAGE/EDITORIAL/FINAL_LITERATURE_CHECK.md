# Final Literature / Attribution Check
## 27 September 2026

This is a targeted final check, not a claim of exhaustive historical priority.

## Direct smooth antecedent

F. Broglia and A. Tognoli, "Approximation of C-infinity-functions without changing their zero-set," Annales de l'Institut Fourier 39 (1989), 611-632.

Primary record and PDF:
https://www.numdam.org/articles/10.5802/aif.1178/
https://aif.centre-mersenne.org/article/AIF_1989__39_3_611_0.pdf

The final manuscript explicitly treats its C-infinity arrangement obstruction as an affine-hyperplane specialization/consequence of this signature-flatness framework and explains the squared-multiplier reduction.

## Ultradifferentiable positive-flat antecedent

A. Rainer, "Ultradifferentiable extension theorems: a survey," Expositiones Mathematicae 40 (2022), 679-757; arXiv:2107.01061.

https://arxiv.org/abs/2107.01061
https://www.tuwien.at/mg/arainer/wp-content/uploads/2025/03/survey-uet.pdf

The final manuscript uses the Denjoy--Carleman criterion and cutoff theorem and acknowledges the stronger positive-flat closed-set construction recorded in the survey.

## Arrangement chamber-function framework

A. N. Varchenko and I. M. Gel'fand, "Heaviside functions of a configuration of hyperplanes," Functional Analysis and Its Applications 21 (1987), 255-270.

https://www.mathnet.ru/eng/faa1225
https://doi.org/10.1007/BF01077800

This is used only as chamber-function context, not as a source for the analytic rigidity theorem.

## MSC verification

The final manuscript uses:

- 26E10: C-infinity functions, quasi-analytic functions.
- 52C35: arrangements of points, flats, hyperplanes.

MSC2020 source:
https://mathscinet.ams.org/mathscinet/msc/msc2020.html

## Fresh finite-order search

Targeted searches were repeated for combinations of finite jets / finite differentiability / sign distributions / hyperplane arrangements / chamber signs. No exact published theorem matching the final C^N affine-arrangement statement was located in those searches.

This negative search result is **not evidence of historical firstness**. The manuscript therefore makes no firstness claim for the finite-order result; it presents it as an explicit formulation extracted from the leading-jet mechanism.
