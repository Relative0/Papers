# Hostile Handling-Editor Report
## Finite-Jet Sign Rigidity on Hyperplane Arrangements and Denjoy--Carleman Realization
### Final submission-candidate review - 27 September 2026

## Editorial decision after the final revision

**SEND TO REFEREES / SUITABLE FOR SUBMISSION AS A SHORT MATHEMATICAL NOTE.**

I would not desk-reject this final version for mathematical correctness, hidden prior art, incoherent scope, or inadequate attribution. The remaining editorial risk is **significance threshold and venue fit**: the principal smooth obstruction and the positive-flat existence mechanism are classical, so the paper should be submitted to a venue that accepts concise research notes, useful reformulations, or focused synthesis rather than one that expects every principal mechanism to be a major new theorem.

This is a materially stronger editorial position than the earlier drafts. The manuscript now states exactly what is classical and makes the finite-order statements and exact realization classification carry the paper's distinct contribution.

## Hostile desk-rejection tests

### 1. Is the headline theorem already known?

The smooth no-flat-point obstruction is known in the signature-flatness tradition, especially Broglia--Tognoli (1989). The manuscript now says this explicitly and gives the reduction next to the theorem. This is no longer a desk-rejection issue based on misleading novelty.

Primary source:
https://www.numdam.org/articles/10.5802/aif.1178/

### 2. Is the finite-order contribution too buried to matter?

Previously, the finite-regularity statements looked like secondary corollaries even though they were the most defensible distinctive formulation. They are now promoted to theorem status:

- finite-order orthant rigidity;
- uniform finite-order arrangement rigidity.

The quantitative obstruction is stated carefully: for a non-parity chamber law, the entire N-jet must vanish somewhere, while the smooth theorem is stronger because it gives a single flat point.

### 3. Is the nonquasianalytic realization mechanism already classical?

Yes in existence form. Positive-flat ultradifferentiable functions on prescribed closed sets are classical; the manuscript now acknowledges that such a function can already be signed chamber-by-chamber to realize arbitrary chamber labelings. The selector construction is retained only for its explicit formula and its clean counting proof.

Modern reference:
https://arxiv.org/abs/2107.01061

### 4. Does the manuscript overstate the originality of the leading Taylor-term idea?

No. It now states that Broglia--Tognoli already use a first nonzero Taylor coefficient in a crossing example, and it identifies their factor-multiplicity argument as the antecedent of the polynomial parity mechanism. The paper's claim is the systematic finite-order/arrangement packaging and exact synthesis, not first discovery of the mechanism.

### 5. Is the paper too long or defensive for a modest contribution?

The hostile-editor revision reduced the paper from 15 to 14 pages while preserving all mathematical results and proofs. Repetitive historical discussion was consolidated. The title and abstract now lead with the actual mathematical package rather than with the history of the audit.

### 6. Is the literature review still missing an obvious neighboring framework?

The final paper directly acknowledges:

- sign distributions and signatures;
- Varchenko--Gelfand chamber functions;
- oriented-matroid/chamber language;
- Denjoy--Carleman quasianalyticity, cutoffs, and positive-flat functions;
- quasianalytic division, resolution, and monomialization as stronger neighboring machinery.

A fresh targeted search for an identical published finite-C^N affine-arrangement rigidity theorem did not surface one. This is **not proof of novelty**, and the paper does not claim historical firstness for that formulation.

### 7. Are the exact counts and classification a coherent endpoint?

Yes. The note now has a clear arc:

finite jet -> crossing parity -> smooth/finite-order rigidity -> Denjoy--Carleman dichotomy -> exact chamber counts.

The exact counts 2^(m+1) and 2^r are not decorative; they provide a clean endpoint and make the analytic distinction visible at the level of realizable chamber functions.

## Changes made in the hostile-editor revision

1. Retitled the paper to foreground the finite-jet rigidity / Denjoy--Carleman realization package.
2. Rewrote the abstract around the actual theorem package and known/new boundary.
3. Added MSC2020 codes and keywords.
4. Promoted the finite-order orthant and arrangement statements to theorem status.
5. Moved the precise Broglia--Tognoli reduction beside the smooth arrangement theorem.
6. Consolidated the literature discussion and removed the nonessential MathOverflow and finite-grid detour.
7. Tightened the positive-flat antecedent paragraph.
8. Condensed the scope/literature section and conclusion.
9. Reduced the manuscript from 15 to 14 pages.
10. Rebuilt the PDF and performed visual and structural QA.

## Mathematical/editorial status

- **Correctness:** no known central flaw after the preceding proof audits and this final pass.
- **Proof completeness:** adequate for external refereeing.
- **Attribution:** sufficiently conservative for submission.
- **Literature coverage:** strong enough for the claims actually made.
- **Novelty:** modest; this remains the paper's weakest category and should not be cosmetically inflated.
- **Coherence:** strong for a short note.
- **Submission type:** research note / analysis note / focused short article.

## What I would tell an editor in one sentence

The paper gives a self-contained finite-jet treatment of chamber-sign rigidity, extracts explicit finite-order obstructions, and combines them with classical Denjoy--Carleman theory to obtain exact realization classifications, while clearly attributing the underlying smooth and positive-flat mechanisms to prior work.

## Final handling-editor verdict

**I would send this version to referees rather than desk-reject it.** A referee could still decide that the contribution is too modest for a particular journal, but that is now a normal significance judgment rather than a correctness, priority, or presentation failure.
