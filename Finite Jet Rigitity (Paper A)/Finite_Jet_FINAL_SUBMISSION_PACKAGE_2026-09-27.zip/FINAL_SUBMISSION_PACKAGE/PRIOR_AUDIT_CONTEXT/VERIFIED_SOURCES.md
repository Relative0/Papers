# Verified / Added Sources

- Broglia, F.; Tognoli, A. (1989), *Approximation of C-infinity-functions without changing their zero-set*, Annales de l'Institut Fourier 39(3), 611--632. DOI: https://doi.org/10.5802/aif.1178 . Primary PDF inspected, including Theorem 4.2 and Remark 4.6.
- Fortuna, E. (1991), *Distributions de signes*, Mathematika 38(1), 50--62. DOI: https://doi.org/10.1112/S0025579300006434 . Publisher extract inspected.
- Acquistapace, F.; Broglia, F. (1992), *Signatures and flatness*, J. Reine Angew. Math. 425, 61--70. Bibliographic record verified from institutional metadata.
- Acquistapace, F.; Broglia, F. (1993), correction to *Signatures and flatness*. J. Reine Angew. Math. 444, 155--156. Correction record verified from institutional metadata.
- Acquistapace, F.; Broglia, F. (1994), *More about signatures and approximation*, Geometriae Dedicata 50(2), 107--116. DOI: https://doi.org/10.1007/BF01265306 . Metadata/summary inspected.
- Acquistapace, F.; Broglia, F.; Fortuna, E. (1994), *When is a distribution of signs locally completable?*, Canadian J. Math. 46(3), 449--473. DOI: https://doi.org/10.4153/CJM-1994-024-2 . Publisher abstract inspected.
- Varchenko, A. N.; Gel'fand, I. M. (1987), *Heaviside functions of a configuration of hyperplanes*, Functional Analysis and Its Applications 21(4), 255--270. DOI: https://doi.org/10.1007/BF01077800 . MathNet abstract and metadata inspected.
- Moseley, D. (2017), *Equivariant cohomology and the Varchenko--Gelfand filtration*, Journal of Algebra 472, 95--114. DOI: https://doi.org/10.1016/j.jalgebra.2016.10.010 . Publisher abstract inspected.

See `LITERATURE_REVIEW_UPGRADE.md` for scope and verification cautions.
