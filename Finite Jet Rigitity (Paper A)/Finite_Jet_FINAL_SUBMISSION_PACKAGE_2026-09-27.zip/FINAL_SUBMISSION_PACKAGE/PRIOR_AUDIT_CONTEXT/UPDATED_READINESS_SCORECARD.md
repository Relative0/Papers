# Updated Publication-Readiness Scorecard
## Revised attributed finite-jet note
### 27 September 2026

These scores apply to the **revised note**, not to the original submission candidate. They are editorial assessments, not acceptance probabilities. The manuscript type has also changed: it is now assessed as a focused analysis/expository research note, not as a paper whose principal claim is a newly discovered smooth rigidity theorem.

| Category | Original /10 | Revised /10 | Change and reason |
|---|---:|---:|---|
| Mathematical correctness | 8.5 | **9.0** | Prior proof repairs retained; new finite-`C^N` corollary follows the audited leading-jet argument. |
| Proof completeness | 8.0 | **9.0** | Arrangement overlap argument is explicit; finite-order corollary is proved. |
| Precision of hypotheses/statements | 8.0 | **9.0** | Contribution boundary and full-class count qualifications are explicit. |
| Internal consistency | 8.5 | **9.0** | The title, abstract, body and conclusion now tell the same contribution story. |
| Denjoy--Carleman conventions | 9.0 | **9.0** | Already strong; normalization unchanged. |
| Arrangement arguments | 8.5 | **9.0** | Local-to-global crossing parity proof remains expanded and finite-regularity variant makes the mechanism clearer. |
| Novelty / differentiation | 3.5 | **5.5** | The known smooth theorem is no longer mis-positioned. Distinctiveness lies in elementary proof, explicit finite-order form and synthesis. This remains a deliberately modest score. |
| Completeness of literature review | 4.5 | **8.5** | Direct signature/sign-distribution lineage and VG chamber-function tradition are now represented. Not claimed exhaustive. |
| Citation accuracy / attribution | 6.0 | **8.5** | Primary 1989 antecedent is directly explained; 1992 correction is acknowledged; peer-reviewed antecedents replace MO as historical center. |
| Resolution of prior concerns | 7.5 | **8.5** | Major priority/framing concern is directly repaired rather than merely caveated. |
| Version/provenance reconciliation | 9.0 | **9.0** | Already strong. |
| Expository clarity | 8.0 | **8.5** | Reader is told what is known and what is contributed before the main results. |
| Accessibility | 7.5 | **8.5** | Signatures/sign-distributions and chamber-function connections are translated into the paper's terminology. |
| Examples/counterexamples | 8.0 | **8.0** | Adequate; no need to enlarge the note merely to raise a score. |
| Scope discipline/focus | 9.0 | **9.0** | Literature expansion remains directly tied to the paper's question. |
| Reproducibility/verifiability | 9.0 | **9.0** | TeX builds, references resolve, PDF was rendered and inspected. |
| Title/abstract/claim calibration | 6.0 | **9.0** | New title and abstract accurately state the known/new boundary. |
| Journal positioning | 5.5 | **8.0** | Manuscript now has a coherent identity as a focused analysis/expository research note. |
| Preprint readiness | 6.0 | **8.5** | Technically and historically much safer; author proofread still recommended. |
| Peer-reviewed submission readiness | 4.5 | **7.5** | Reasonable as a short note after final author check; significance is now the main editorial question, not hidden priority risk. |

## Gate update

### Gate A - mathematical validity
**PASS**, subject to ordinary author proofreading.

### Gate B - priority / novelty
**CLOSED ENOUGH FOR THE REFRAMED CLAIMS.**

The principal `C^infinity` obstruction is attributed as known. The manuscript makes no firstness claim for the finite-regularity arrangement corollary. Therefore the key historical-risk gate no longer depends on proving a negative literature-search proposition.

### Gate C - preprint readiness
**READY AFTER FINAL AUTHOR PROOFREAD.**

No mathematical or citation blocker was found in the revised build. A final human read for authorial voice, bibliography details and preferred terminology remains appropriate before public release.

### Gate D - journal submission readiness
**SUBSTANTIALLY READY AS A SHORT NOTE; FINAL POSITIONING CHECK RECOMMENDED.**

The remaining question is not whether the manuscript hides a known theorem, but whether a chosen venue regards the elementary proof + finite-order formulation + ultradifferentiable synthesis as enough contribution for its note format.

## Why the novelty score remains modest

A lower novelty score is not a defect to be cosmetically repaired. The revision is stronger precisely because it no longer asks a known `C^infinity` obstruction to carry the paper's originality. The manuscript's publishable case is instead:

- a short and transparent leading-jet proof;
- an explicit `C^N` arrangement obstruction;
- a clean normalization of the Denjoy--Carleman dichotomy;
- exact orthant/arrangement realizability counts in the full Roumieu classes;
- a bridge between analytic sign rigidity and the language of chamber functions / Boolean laws.

Whether this is enough for a particular journal is a matter of scope and editorial interest, not a correctness problem.

