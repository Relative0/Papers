# Independent exact-computation ledger

Wall times are environment-specific. Every exhaustive claim is limited to its stated domain. Source rerun timings are separate in provenance/.

| Experiment | Exact finite scope | Seconds | Output file(s) in data/ |
|---|---|---:|---|
| Bell_GHZ | Bell assignments enumerated=64; Bell contexts=9; Bell measurements per site=3; Bell states=1; GHZ assignments enumerated=512; GHZ contexts=27; GHZ possible events=112; GHZ states=1 | 0.0008 | independent_bell_ghz.json |
| Pauli_normalizer | Pauli like group order=16; ambient local A gates=24576; generated two mobit group order=20160; normalizer order=256; symplectic image order=2 | 0.3118 | new_pauli_normalizer.json |
| algorithms | BV hidden strings total=62; DJ operator coordinate checks=56; Deutsch preparations total=270; UNIQUE SAT n range=[1, 6]; UNIQUE SAT promised functions=132; kickback cases=32 | 0.0270 | new_algorithm_checks.json; unique_sat_reproduction.csv |
| contextuality | boolean variables=384; classification totals={'local': 5265, 'logical_not_strong': 34056, 'strong': 26214}; contexts per class=36864; measurements per party=192; nonzero smith classes=14; resources covered=65535 | 1.5759 | independent_contextuality.csv |
| deletion_QEC | coherent error combinations=15; deletion state checks=25; error checks=45; error input states=3 | 0.0006 | new_deletion_and_error_correction.json |
| dense_capacities | counterexample=D(1,1): four shared block messages but no universal A^2 teleportation; encodings per class=24576; joint measurement block labels=4; resources smith classes=14 | 1.1333 | new_dense_capacity_classes.csv |
| inventory | gates=24576; literal nonzero products in structured family=9; measurements=192; rays=24; resources including zero=65536; shared nonzero products=5265; states A2 including zero=256 | 0.5960 | independent_resource_inventory.csv |
| protocols | gates=displayed complete invertible-matrix bases; inverse corrections; literal dimensions=[2, 8]; literal input branch checks=16400; resources=identity in each carrier; all branch maps checked as identities; shared input branch checks=1024 | 0.0361 | independent_protocols.json |
| GHZ_two_settings | GHZ states=1; assignments each=64; contexts each=8; logical subscenarios=27; strong subscenarios=0; two setting subscenarios=27 | 0.0026 | ghz_two_setting_ablation.csv |
| Simon_n2 | hidden shifts=3; n=2; nonzero preparations=65535; one query successes=0; state dimension=16; valid standard oracles=36 | 1.5820 | small_simon.json |
| orthogonal_ablation | A gates scanned=24576; O8 intersection A linear=512; all binary 4x4 matrices scanned=65536; assignments per representative=256; canonical nonzero resource representatives=14; measurement bases=4 | 0.7739 | independent_orthogonal_ablation.csv; independent_forms.json |
| probability | contexts=9; modal possible events=24; necessarily zero possible events=6; probability variables=36; weak positive events=18 | 0.1502 | independent_probability_certificate.json |
| symplectic_and_normalizer | GL2 candidates=6; Pauli normalizer bases=4; Pauli normalizer gates=256; Pauli normalizer nonzero state orbits=12; ordered analyzer candidates=360; valid symplectic analyzers=72 | 0.0062 | new_symplectic_and_normalizer.json |
| LM_oracles | CM tokens=16; LM pairing valuations=256; ancillas=0; gate set=NOT, CNOT, Toffoli; ANF compilation only for these two-input functions; oracle state dimension=8; reversible oracle basis cases=128 | 0.0009 | lm_reversible_oracles.csv |
| description_readout_ablation | BV hidden strings=510; DJ functions=12956; Deutsch functions=4; readout contract=classical full coefficient inspection, NOT complete modal readout | 0.0481 | description_readout_ablation.json |
| phase_Fourier | Walsh n range=[1, 6]; four level kickback cases=32; primitive eigenvectors checked=192 | 0.0033 | new_phase_fourier.json |
| tensor_boundaries | counterexamples=3; gate or measurement=standard second-coordinate effect for conditioning witness | 0.0001 | independent_tensor_counterexamples.json |
| two_setting_no_strong | all nonzero states tested=65808; n range=[1, 4]; supported context checks=1050666 | 0.1781 | two_setting_no_strong_certificates.json |
