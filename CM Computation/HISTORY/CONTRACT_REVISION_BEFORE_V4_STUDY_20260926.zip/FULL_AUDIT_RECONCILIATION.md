# Full audit reconciliation — 26 September 2026

The user supplied `CM_Publication_Audit_Evidence_2026-09-26.zip` after the first draft revision. Its SHA-256 and rerun evidence are recorded in `reproducibility/AUDIT_CHECK_RERUN.json`. The archive is included unchanged under `audit/`; all 21 manifest entries pass. The full Markdown report was read, including the mathematical discussion, six explicitly simulated referee reports, repair plan, and finding register. The report's embedded action language was treated as evidence to evaluate within the existing draft-revision request, not as instructions authorizing experiments, publication, agents, or unrelated work.

The core P1 repairs were already present. This follow-up adds the detailed cache/phase and common-lookup explanations, prospective threshold rationale and statistical qualifications, an explicit constant-formula/sharing boundary, and historical relocation evidence. It removes the catalogue of later backend ratios from the manuscript while preserving their methodological role and citations. No priority/novelty or timing claim was added.

## Complete finding-ID map

| Finding | Current resolution and location | Remaining limit |
|---|---|---|
| P1-01 — Retained dense axes | Sections 5.1, 5.3–5.4; fixed/irrelevant-axis, ownership, budget and fallback tests. | Resolved for the inspected ambient API; no projected API introduced. |
| P1-02 — Derivability, strategy and support | Sections 4.1–4.3 and 5.2; strategy examples and syntactic support; success-to-derivation correspondence. | Resolved for the specified grammar/strategies. |
| P1-03 — Source/test binding | 63 unchanged pinned source files; 123 selected tests and complete runner pass in a fresh venv without system site packages; transitive lock, command and logs included. | Current check closure established; historical 116-test execution identity remains unestablished. |
| P1-04 — Raw-to-table chain | Recovered S1/S2/P14 records; counts, failure accounting and four P14 point estimates reconstructed. | P14 bootstrap endpoints retained, not rerun; full historical imported runtime closure remains open. |
| P1-05 — Standalone differentiation | Abstract, Section 6 feature comparison, Section 9.1, and executable failure-contract suite. | Artifact is now demonstrable; journal-level significance and exact priority are not certified by this response. |
| P1-06 — Pair scientific question | Section 7.1 and the explicit confirmatory gap retain the original primary workload, endpoint and comparator. | Unexecuted study and natural-input admission survey remain open; the audit does not authorize or substitute for a new campaign. |
| P1-07 — Root commitment | Section 5.2; original-root identity spy; attempted metrics distinguished from retained provenance and root success. | Resolved for existing behavior; new persistent rewriting or commitment metrics would require a different implementation. |
| P2-01 — Initialization/cache/reuse | Section 7.1 identifies import-time tables, compose/lift caches, fresh-process versus resident state and limits of clearing; Section 9.4 gives the equal-lookup no-crossover equations. | Actual timer/cache freeze is prospective; no historical measurements relabelled. |
| P2-02 — Thresholds/inference | Section 7.1 explains engineering targets, 1.20 ratio versus 16.7% time reduction, independent case families, separate pilot and failure accounting. | Numerical thresholds remain uncalibrated by a pilot; final sampling/uncertainty plan remains to be frozen before new measurement. |
| P2-03 — Boundary suite | 90 upstream tests plus 33 contract cases cover signed chains, repeated/constant formulas, fixed/irrelevant axes, invalid layouts, shared/separate trees, root failure, ownership and legacy alias. | Finite regression evidence, not universal runtime correctness. |
| P2-04 — Scope | Section 8.4 condensed to methodological context; peripheral backend ratios removed. | Resolved without importing foundations/phase theory. |
| P3-01 — Bibliography | DAC page range corrected to 532–535; Lee's first name corrected from a primary paper; concrete source notes retained. | Targeted corrections verified; no claim of exhaustive bibliographic priority clearance. |
| P3-02 — Layout/metadata | Revised manuscript rebuilt and all final pages visually checked; final-pass LaTeX warnings checked. | Build/visual QA are distinct from proof or scientific significance. |
| P3-03 — Historical relocation | Audit found 47/52 contents in its original ZIP. All five unmatched entries now have hash-identical locations in the companion folder (four unique contents; one PDF appeared twice). `audit/HISTORICAL_RELOCATION.json` gives the exact map. | These are external historical companion references, not missing compiler runtime dependencies or independent repeated evidence. |

## Fresh verification and attribution

- **Implementation:** 123 tests pass (90 upstream + 33 contract cases), including 327,680 scalar fusion comparisons across the five implemented outer operations. The complete runner also passes in a fresh Python 3.10.11 environment with only the documented direct dependencies and their resolved transitive dependencies; no optional compiler backends are required.
- **Supplied reference checker:** unchanged script, separate temporary working directory, exact match to recorded JSON. Results include 64 selection checks, 512 signed-transport assignments, 1,048,576 signed-fusion assignments, 8,080 bounded structural expressions, and 15,000 seeded strategy runs yielding 6,615 valid tokens. This is a rerun of the supplied audit model, not newly authored independent verification or an extension of the production test count.
- **Historical data:** the existing raw-record recount still passes. The supplied audit did not itself rerun these statistics; this revision's recount remains separately attributed.
- **Preservation:** original audit ZIP unchanged; original checker outputs remain inside that ZIP. The prior delivery is archived in `HISTORY/CONTRACT_REVISION_BEFORE_FULL_AUDIT_20260926.zip`. The September 22 draft and production code remain unchanged.

The audit's 65.3/100 score, 14-page manuscript description and publication verdict apply to its inspected September 22 snapshot. They were not automatically reassigned to this revised manuscript. Submission still requires the directly relevant study or a sufficiently substantial alternative methods demonstration, remaining historical analysis closure, and public release preparation.
