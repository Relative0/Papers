# N2/P12 Reproducibility

P12 is an implementation-only replay of the frozen P11/P8 dispatch policy with lazy reuse exactification and exact pair-repeat derivation.

## Frozen hashes

- preregistration: `90963ffa72693a066b2bc9441887f586204015c647684c68e7cb9afef7a3b3f7`
- harness: `d453974ccdbdc78569792e97a7b46f971047bdd3ba5c8b1beb94434293c42549`
- P8 frozen gate: `ebc2de96f8219043da66db02bd3bcd38b8455594d5684a1756c7ed13fb4cd64f`

## Reproduction order

1. `python cm_n2_p12_run/n2_p12_harness.py --mode invariant --out cm_n2_p12_run/invariance.json`
2. `python cm_n2_p12_run/n2_p12_harness.py --mode fuzz --out cm_n2_p12_run/fuzz.json`
3. `python cm_n2_p12_run/n2_p12_harness.py --mode gatep --out cm_n2_p12_run/gatep.json`
4. Run the ten frozen natural cases with `--mode natural-case`; `cavlc:35` may be split deterministically with `run_p12_nat_chunk.py` under short command wall limits.
5. Merge deterministic chunks, calculate `N2_P12_SUMMARY.json`, run `independent_verify.py`, then `make_p12_artifacts.py`.

The 332-case P11/P12 decision-invariance gate and 1,000-case fuzz are mandatory before timing interpretation. No model fitting, cutoff selection, or fold-threshold tuning occurs in P12.
