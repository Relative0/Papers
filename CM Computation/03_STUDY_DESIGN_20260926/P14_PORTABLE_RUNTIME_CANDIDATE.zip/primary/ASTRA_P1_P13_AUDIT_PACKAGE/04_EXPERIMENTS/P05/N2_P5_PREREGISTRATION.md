# N2/P5 Preregistration — Packed Construction Metadata with Demand-Time Profitability Arithmetic

Frozen before any N2/P5 fuzz, Gate-P, or natural benchmark result is inspected.

## Goal

Test whether the P4 lowering-stage speedup can survive the full DAG-construction pipeline when the successful propagated two-support signature is retained but construction metadata is reduced to packed primitive arrays and all profitability-candidate arithmetic is deferred until a node is actually demanded by sparse-ANF lowering.

P5 is an implementation/representation refinement of P4, not a new profitability policy. The mathematical fold rule, signature precedence, Gate-P corpus, natural corpus, and direct/no-rewrite baseline remain frozen.

## Frozen profitability rule

P5 reuses the N2/P1-P4 rule unchanged:

- saturating structural ANF-size estimate cap: `4096`;
- reject estimated benefit `<= 0`;
- reject estimated benefit `< 16` pair terms;
- shared child threshold: estimated relative benefit `>= 20%`;
- unshared child threshold: estimated relative benefit `>= 10%`;
- no arbitrary truth-table retabulation;
- no general NOT-over-two-support propagation.

No threshold may be tuned after P5 results are observed.

## Packed construction metadata

`PackedMetaFactory` preserves the exact Boolean DAG semantics and local simplifications of the frozen ordinary `Factory`, while maintaining side metadata indexed by node id.

No `Sig` or `Candidate` Python object is allocated per node.

The only persistent P5 metadata are packed primitive fields:

1. `use_count[nid]`: unsigned edge-use count, incremented once for every edge of a newly materialized unique parent;
2. `m_est[nid]`: saturating P1 monomial estimate (`0..4096`);
3. `sig_a[nid]`, `sig_b[nid]`: unsigned node ids for the ordered two-support base pair, or one frozen sentinel for no signature;
4. `sig_token[nid]`: four-bit truth-function token;
5. `sig_propagated[nid]`: one byte indicating that the stored signature was obtained by composing through at least one child shell rather than merely recording the node's immediate/native two-support shell.

The signature propagation rule and candidate-pair precedence are identical to P4:

- native signatures exist for binary `AND`, `OR`, `XOR`, and non-degenerate `TF` nodes;
- for `AND`, `OR`, and `XOR`, try the propagated pair of the left child first, then the right child if distinct;
- align direct base operands, `NOT(base)`, same-orientation child signatures, and swapped-orientation child signatures exactly as in P4;
- require at least one child shell to compose through;
- if composition succeeds, store only the resulting `(a_id,b_id,token)` and the propagated flag;
- otherwise retain the native immediate signature;
- do not propagate a general two-support signature through a standalone `NOT` node.

No pair-cost, shell-cost, fold-cost, benefit, sharing, or Candidate record is computed or stored during construction.

## Demand-time P5 lowering

Primary arm: `cm_packed_sig_sparse`.

At a demanded node:

1. if `sig_propagated[nid] == 0`, fall through immediately to the exact direct sparse-ANF rule;
2. otherwise read the packed parent signature and align the two immediate children to that ordered pair;
3. compute child token estimates, parent pair cost, live shell costs, fold cost, sharing status, benefit, and frozen fractional threshold at that moment only;
4. if accepted, lower only the surviving base pair and apply the composed truth token;
5. if rejected, execute the exact direct rule for that node.

No candidate object, rewrite graph, fold plan, recursive matcher, recursive estimator, or reference-count scan is permitted in the P5 lowering path. Every accepted fold must be consumed.

Small token algebra constants may be precomputed in fixed 16-entry integer tables; this does not alter the profitability rule.

## Equivalence requirement to P4

Because P5 changes only metadata representation and the time at which candidate arithmetic is performed, P5 must reproduce P4-propagated behavior exactly on every fuzz and benchmark case:

- same final ANF digest;
- same multiplications, pair terms, peak monomials, evaluated ANF nodes, and final monomial count;
- same number of selector candidates actually demanded;
- same accepted fold count;
- same accepted-shared count;
- same reject-reason counts.

Construction metadata is also checked node-by-node against P4 on fuzz cases: edge-use counts, monomial estimates, propagated signature presence, base pair, token, and whether P4 had a propagated candidate.

Any semantic/signature mismatch aborts P5 without changing the rule.

## Timing endpoints

### A. Lowering-only

Materialize the P5 packed DAG once before timing.

Arms:

- `direct_packed_sparse_anf`: direct/no-rewrite sparse ANF on the same P5 DAG, ignoring metadata;
- `cm_packed_sig_sparse`: P5 primary;
- `cm_meta_sig_sparse`: simultaneous frozen P4-propagated reference on a structurally identical P4 metadata DAG.

Primary lowering comparison: `cm_packed_sig_sparse / direct_packed_sparse_anf`.

P5/P4 is an implementation diagnostic.

### B. DAG construction + lowering

Each repetition freshly clones the frozen source DAG:

- `direct_build_sparse`: ordinary Factory clone + direct sparse-ANF;
- `cm_meta_sig_build_sparse`: P4 MetaFactory clone + P4 propagated lower, simultaneous reference;
- `cm_packed_sig_build_sparse`: P5 PackedMetaFactory clone + P5 lower.

Primary end-to-end comparison: `cm_packed_sig_build_sparse / direct_build_sparse` using `pipeline_ns = dag_build_ns + lower_ns` measured inside one outer timer.

Report build-only ratios P5/direct and P5/P4 separately.

BLIF parsing, oracle construction, result serialization, and truth-vector conversion are outside the timed pipeline endpoint.

## Corpora

### Natural EPFL replay

Replay the exact frozen N2/P1-P4 snapshot and ten-case structural selection:

- EPFL commit `0060e156826e733d69bf5b3322d1bdd0d03a1f9a`;
- exact pinned BLIF blobs for adder, bar, CAVLC, int2float, priority, router;
- support 9-12;
- transitive source-node count <= 128;
- first and last admissible case by `(source_nodes, depth, root_name)`;
- `bar` may contribute zero timed cases exactly as before.

No case may be selected because P4/P5 folds it or because of timing.

### Gate-P replay

Replay the exact frozen generator, seed family, order, depths `6,8,10`, and `12` cases per depth. Before timing, direct final ANF identity/work fields must match the frozen P4/P3 reference on all 36 cases.

## Correctness and invariants

Before benchmark timing:

- run 1000 fresh randomized formulas through original direct, direct-on-P5-DAG, P5, P4, P3, and P2;
- require oracle equality and identical final ANF digest;
- require P5 direct structural work to equal original direct;
- independently recompute fanout and monomial estimates and compare to packed arrays;
- compare P5 packed signatures node-by-node with P4 propagated signatures;
- require P5 selector/work statistics to match P4 propagated exactly;
- every accepted P5 fold must be consumed;
- require ordinary/P4/P5 clones to preserve direct reachable-node and ANF-work identity.

## Repetitions

To preserve comparability with P4:

- Natural lowering-only: 25 randomized paired repetitions/case/arm;
- Gate-P lowering-only: 25 randomized paired repetitions/case/arm;
- Natural construction-inclusive: 15 randomized paired repetitions/case/arm;
- Gate-P construction-inclusive: 15 randomized paired repetitions/case/arm;
- memory: separate untimed passes.

Case medians are formed first. Pooled ratios use the geometric mean of paired case-median ratios with a case bootstrap 95% interval.

## Predeclared interpretation

### Lowering-only speed signal

For a corpus with at least one consumed P5 fold, PASS requires:

1. zero correctness/equivalence/invariant failures;
2. pooled P5/direct lower-time ratio `<= 0.95`;
3. bootstrap 95% upper bound `< 1.00`;
4. no >5% pooled increase in pair terms or peak monomials versus direct.

If no fold is consumed, report abstention overhead only.

### Construction-inclusive speed signal

For a corpus with at least one consumed P5 fold, PASS requires:

1. all correctness/equivalence/work constraints above;
2. pooled P5/direct pipeline ratio `<= 0.95`;
3. bootstrap 95% upper bound `< 1.00`.

### P5 engineering success diagnostic

Regardless of end-to-end PASS/FAIL, report:

- P5 packed DAG build / ordinary DAG build;
- P5 packed DAG build / P4 metadata DAG build;
- P5 lower / P4 lower;
- P5 pipeline / P4 pipeline;
- traced Python peak ratios for P5/direct and P5/P4;
- P5/P4 equality of fold decisions and symbolic work;
- count of Gate-P cases below direct in lowering-only and full pipeline time;
- depth-stratified Gate-P ratios;
- natural results separately, with no natural-folding claim if zero natural fold is consumed.

A lowering-only win plus a materially reduced construction ratio but no end-to-end win means packing solved part of P4's metadata cost but not enough. An end-to-end win is the stronger P5 result.
