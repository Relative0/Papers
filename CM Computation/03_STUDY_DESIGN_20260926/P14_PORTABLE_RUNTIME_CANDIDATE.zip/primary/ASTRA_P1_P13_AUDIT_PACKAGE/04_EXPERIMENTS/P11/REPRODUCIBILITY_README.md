# N2/P11 Reproducibility

P11 is an implementation-only replay of the frozen P8/P10 dispatch policy with threshold-specialized telemetry.

## Frozen hashes

- preregistration: `2a6f61652058ec6b1d8db4ab77f1cb9e34032f385406d783f821a23db701f304`
- harness: `9131551f9c7ab7f59ca49b31d348d988684665800b6cf806a6f1ba4a180db455`
- P8 frozen gate: `ebc2de96f8219043da66db02bd3bcd38b8455594d5684a1756c7ed13fb4cd64f`

## Reproduction order

1. `python cm_n2_p11_run/n2_p11_harness.py --mode invariant --out cm_n2_p11_run/invariance.json`
2. `python cm_n2_p11_run/n2_p11_harness.py --mode fuzz --out cm_n2_p11_run/fuzz.json`
3. `python cm_n2_p11_run/n2_p11_harness.py --mode gatep --out cm_n2_p11_run/gatep.json`
4. Run the ten frozen natural cases with `--mode natural-case`; `cavlc:35` may be split deterministically with `run_p11_nat_chunk.py` under short command wall limits.
5. Merge any deterministic chunks, calculate `N2_P11_SUMMARY.json`, run `independent_verify.py`, then `make_p11_artifacts.py`.

The 332-case P10/P11 decision-invariance gate and 1,000-case fuzz are mandatory before timing interpretation. No model fitting, cutoff selection, or fold-threshold tuning occurs in P11.
