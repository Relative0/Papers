# N2/P11 Preregistration - Frozen-Tree Specialized Telemetry

Frozen before any P11 invariance result, fuzz result, Gate-P timing, natural timing, memory result, or profiling result is inspected.

## Goal

Test whether P10's remaining source-construction premium can be reduced by compiling the already-frozen P8 dispatch tree itself into a minimal telemetry path, rather than maintaining generic feature state that is not needed to decide annotate versus bypass.

P11 is an implementation experiment only. It does **not** retrain the tree, change the cutoff, alter any P6/P1 folding threshold, alter any benchmark case, or change the direct/P6 compiler backends.

## Frozen policy inherited unchanged

P11 reuses the exact frozen P8 gate from `cm_n2_p8_run/P8_FROZEN_GATE.json`:

- cutoff: `0.80`;
- same depth-3 tree;
- same P6 folding backend;
- same P1 profitability thresholds.

Inspection of the already-frozen tree shows that the **annotate decision** occurs only at leaf 10. Therefore the frozen decision is logically equivalent to the conjunction:

1. `max_pair_shells > 4.5`, i.e. at least one canonical binary operand pair occurs at least five times;
2. `reuse_density <= 0.44374121725559235`;
3. `pair_repeat_density <= 0.16333333402872086`.

All leaves reachable when `max_pair_shells <= 4.5` have predicted ratio greater than the frozen `0.80` cutoff. P11 specializes only this already-frozen decision; it does not choose or fit the conjunction.

## P11 telemetry under test

`TreeSpecializedTelemetryFactory` fuses ordinary hash-consed source construction and only the state required by the frozen annotate predicate.

It maintains:

- `edge_count`;
- `binary_nodes`;
- `reuse_edge_events`;
- `pair_repeat_excess`;
- a one-bit `shell_ge5` flag;
- one `bytearray` marking whether each node has previously received an incoming edge;
- a canonical operand-pair dictionary whose counts saturate at five until `shell_ge5` becomes true; after that, pair values are no longer incremented because only seen/unseen membership is needed for `pair_repeat_excess`.

P11 deliberately does **not** maintain:

- per-node depth;
- maximum depth;
- node density / binary density;
- generic feature dictionaries during timed construction;
- unused frozen-tree branches.

At dispatch time the two density thresholds are evaluated by integer cross-multiplication against the exact binary-float threshold ratios from the frozen tree (`float.as_integer_ratio()`), avoiding feature division in the P11 timed path.

## Mandatory P10/P11 decision invariance

Before timing interpretation, P11 must match P10 on all 332 frozen policy cases:

- 188 P8 training cases;
- 98 P8 validation cases;
- 36 Gate-P evaluation cases;
- 10 natural evaluation cases.

For each case require:

- identical ordinary Boolean semantics / node identity digest;
- `edge_count`, `binary_nodes`, `reuse_edge_events`, and `pair_repeat_excess` equal P10;
- `shell_ge5 == (P10.max_pair_shells >= 5)`;
- identical annotate/bypass decision to the full frozen P8 tree evaluated on P10 features.

Exact P10 leaf-ratio reproduction is **not** required on bypass cases because P11 intentionally does not compute the unused left-subtree features. Decision equivalence is the frozen invariant.

Any mismatch aborts performance interpretation.

## Correctness gate

Before timing interpretation, run 1,000 fresh fuzz formulas. Require:

- ordinary, P10, and P11 source DAG semantics agree;
- the P11 counters above match P10 exactly;
- P10 and P11 annotate/bypass decisions agree;
- direct and P6 compiler results match the independent Boolean oracle/digest;
- the selected P11 backend's Boolean-work metrics equal the corresponding frozen direct/P6 backend;
- P6 accepted-fold count equals fold-lowering count.

Any mismatch aborts interpretation.

## Evaluation corpora

### Gate-P

Replay exactly the frozen 36-case Gate-P evaluation family: depths 6, 8, and 10; 12 cases per depth; original frozen RNG/order.

### Natural EPFL

Replay exactly the frozen ten natural cones used in P1-P10 from EPFL commit `0060e156826e733d69bf5b3322d1bdd0d03a1f9a`.

No natural-folding claim is permitted unless P11 dispatches to P6 and actually consumes a fold on a natural case.

## Simultaneous source-inclusive arms

Randomize four arms within each timing schedule:

1. `direct_source_pipeline` - ordinary source Factory + direct/no-rewrite sparse ANF;
2. `p6_source_pipeline` - ordinary source Factory + always-P6 compiler;
3. `p10_fused_source_dispatch` - P10 seven-counter fused telemetry + frozen P8 gate;
4. `p11_tree_specialized_dispatch` - P11 specialized threshold-aware telemetry + the exactly equivalent frozen annotate decision.

This simultaneous design isolates P11/P10 implementation cost while controlling machine drift.

## Timing

- Gate-P: 20 randomized repetitions per case per arm.
- Natural: 15 randomized repetitions per case per arm.
- Separate untimed `tracemalloc` passes are permitted.
- Case medians are formed first.
- Pooled ratios use case-balanced geometric means with 5,000 bootstrap resamples for 95% intervals.
- Workload-weighted summed-median ratios and per-case wins are secondary.

## Primary endpoint

`P11 / direct` source-inclusive time, from source-DAG construction through selected compiler construction and sparse-ANF lowering.

## Secondary endpoints

Report at minimum:

- P11/P10 source-inclusive ratio;
- P11/P6 source-inclusive ratio;
- P11/direct source-build ratio;
- P11/P10 source-build ratio;
- P11/direct selected-compiler ratio;
- workload-weighted versions;
- Gate-P depth strata;
- exact dispatch counts;
- Boolean-work ratios versus direct;
- traced peak-allocation ratios.

## Predeclared signals

### Gate-P direct-crossover PASS

Requires all of:

1. zero correctness failures;
2. exact P10/P11 decision invariance on all 332 frozen cases;
3. at least one Gate-P case dispatched to P6 and consuming a fold;
4. P11/direct source-inclusive case-balanced geomean <= `0.95`;
5. bootstrap 95% upper bound < `1.00`;
6. no greater than 5% pooled increase in pair terms or peak monomials versus direct.

### Specialized-telemetry engineering success

Independently report success if all hold:

1. exact P10/P11 decision invariance;
2. P11/P10 source-build case-balanced geomean <= `0.90`;
3. P11/P10 source-inclusive case-balanced geomean <= `0.98`;
4. bootstrap 95% upper bound for P11/P10 source-inclusive < `1.00`.

## Guardrails

- No frozen tree value, cutoff, fold threshold, case, repetition count, or endpoint may change after P11 results are seen.
- No P11 timing may be used to modify the specialized predicate or telemetry representation.
- No new learned gate or case-specific exception is permitted.
- P11 is a CPython implementation experiment. A win would demonstrate cheaper exposure of the already-frozen folding/dispatch mechanism; it would not establish uniqueness to CM or general natural-circuit acceleration.
