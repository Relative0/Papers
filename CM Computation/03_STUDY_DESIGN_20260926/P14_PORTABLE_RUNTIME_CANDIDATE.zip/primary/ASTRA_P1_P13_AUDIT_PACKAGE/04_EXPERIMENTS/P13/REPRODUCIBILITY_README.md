# N2/P13 Reproducibility

P13 is an implementation-only replay of the frozen P12/P11/P8 dispatch policy with deferred C-backed exact pair statistics.

## Frozen hashes

- preregistration: `28cd2f282764cd34d2c9c3bc2c9beca283fb34bf5d8f3900789f58a87eaf922a`
- harness: `9678b4e8e5d75980c235411462e6999d159f55f911b4bcf582168d55b2beeedb`
- P8 frozen gate: `ebc2de96f8219043da66db02bd3bcd38b8455594d5684a1756c7ed13fb4cd64f`

## Reproduction order

1. `python cm_n2_p13_run/n2_p13_harness.py --mode invariant --out cm_n2_p13_run/invariance.json`
2. `python cm_n2_p13_run/n2_p13_harness.py --mode fuzz --out cm_n2_p13_run/fuzz.json`
3. `python cm_n2_p13_run/n2_p13_harness.py --mode gatep --out cm_n2_p13_run/gatep.json`
4. Run the ten frozen natural cases with `--mode natural-case`; `cavlc:35` may be split deterministically with `run_p13_nat_chunk.py` under command wall limits.
5. Merge deterministic chunks, calculate `N2_P13_SUMMARY.json`, run `independent_verify.py`, then `make_p13_artifacts.py`.

The 332-case P12/P13 decision-invariance gate and 1,000-case fuzz are mandatory before timing interpretation. No model fitting, cutoff selection, fold-threshold tuning, or post-result pair-strategy modification occurs in P13.
