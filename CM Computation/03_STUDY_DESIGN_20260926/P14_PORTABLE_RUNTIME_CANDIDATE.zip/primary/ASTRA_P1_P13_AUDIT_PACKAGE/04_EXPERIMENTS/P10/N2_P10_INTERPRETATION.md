# N2/P10 Interpretation

P10 answers the clean implementation question posed by P9: how much of the remaining dispatch tax came from wrapping the ordinary `_make` and then revisiting each new node?

The answer is **a measurable but limited fraction**. With every policy decision frozen, P10/P9 source construction was **0.9344x** and P10/P9 full source-inclusive time was **0.9766x**. P10 won the source-build comparison on all 36 Gate-P cases and the full-pipeline comparison on 30/36 cases. Thus the wrapper architecture was genuinely wasteful.

But it was not the dominant remaining cost. P10 source construction is still **1.5204x direct**. The selected compiler path itself is **0.9702x direct case-balanced** and **0.8314x workload-weighted**, so the residual problem remains almost entirely the act of carrying the dispatch telemetry through Python construction.

The post-hoc profile is consistent with this. Across the same 360 Gate-P builds, cProfile reports approximately 0.069 s total for ordinary construction, 0.098 s for P9, and 0.093 s for P10. P10's fused `_make` accounts for about 0.042 s cumulative, versus roughly 0.052 s for P9's wrapper `_make` (which includes calls into the base `_make`). These profile totals are diagnostic only; the randomized timing benchmark is authoritative.

The post-hoc zero-incremental-telemetry bound remains important: preserving the exact P10 decisions and compiler medians while charging only direct source-build cost gives **0.9664x** direct case-balanced and **0.8849x** workload-weighted. This strongly suggests that the current frozen dispatch/folding combination already contains enough downstream savings for crossover if the telemetry can be made close to free.

## Recommended P11

The next clean pass should **not** refit the tree and should not change any fold threshold. It should attack the fact that P10 still maintains all seven primitive counters for every node even though the frozen depth-3 tree does not necessarily need all of them on every formula.

A P11 tree-aware lazy telemetry implementation can exploit the exact frozen tree structure:

1. The root asks only whether `max_pair_shells <= 4.5`.
2. If the final root branch is left, only the features reachable in that subtree are relevant: `binary_density`, `max_depth`, and `pair_repeat_density`.
3. If the root branch is right, only `reuse_density` and `pair_repeat_density` are subsequently needed.
4. Counters whose final value cannot affect the reached leaf should be omitted or maintained only after the branch becomes reachable, **without a second DAG traversal**.

The safest P11 should preregister **exact P10 decision equivalence on all 332 frozen policy cases plus fresh fuzz before timing**, exactly as P9/P10 did. It should have two arms if practical: (A) tree-aware lazy counters and (B) an even tighter specialized decision-state machine that evaluates the frozen tree from primitive running bounds rather than materializing a feature dictionary.

This is more promising now than further container/layout changes because P10 has already removed the wrapper call and still leaves a ~52% source-build premium. The remaining overhead is the counter maintenance itself.
