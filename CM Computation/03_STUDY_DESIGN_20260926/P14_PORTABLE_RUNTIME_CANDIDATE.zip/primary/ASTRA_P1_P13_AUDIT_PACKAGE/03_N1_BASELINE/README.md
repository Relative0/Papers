# N1 / Gate-P reproduction

Primary run:

```bash
python n1_gatep_harness.py --blif int2float_depth_2025.blif --out .
```

The harness refuses to run unless the BLIF Git blob hash is `ac0cb9d3f2f576f05a14ceb2604a843c16526c8e`.

Post-hoc sharing diagnostic:

```bash
python sharing_guard_diagnostic.py
```

Read `N1_GATEP_RESULTS.md` first, then `SHARING_GUARD_DIAGNOSTIC.md`. Raw observations are in the JSON files. The sharing guard is deliberately post-hoc and does not alter the pre-registered N1 outcome.
