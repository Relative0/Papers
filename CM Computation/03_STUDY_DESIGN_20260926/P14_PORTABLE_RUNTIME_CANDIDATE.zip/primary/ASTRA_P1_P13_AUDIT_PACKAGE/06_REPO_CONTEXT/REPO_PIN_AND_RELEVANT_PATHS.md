# Broader repository context

The P1-P13 experiment harnesses in this bundle are the authoritative implementation for the audit. They form an import chain back to `03_N1_BASELINE/n1_gatep_harness.py`.

For broader project context, the relevant public repository is:

- Repository: `Relative0/Correspondence_Matrices`
- Pinned commit used during this work: `1145537c9e2274ae7622dad5b68a7d612b27bb7e`

If Astra has GitHub/web access, useful additional files at that exact commit include:

- `README.md`
- `cm_ir.py`
- `cm_lm.py`
- `cm_token.py`
- `cm_pair.py`
- `cm_build_pair.py`
- `cm_exprlib.py`
- `cmbench/recognition/blif.py`
- `cmbench/recognition/cut_fusion.py`
- `cmbench/recognition/natural_profitability_policy_experiment.py`
- `cmbench/recognition/computation_experiment.py`
- `cmbench/recognition/adaptive_dispatcher_experiment.py`
- `cmbench/recognition/exact_dispatcher.py`

These files are **not required to execute the P-series harness chain** and are not duplicated here because the complete pinned repository snapshot was not available as a local archive during bundle construction.

If the user has a local checkout, adding a zip/tarball of the repository at the exact pinned commit would improve the audit of stronger generic baselines and relation to older optimization code.

## EPFL benchmark pin

- Repository: `lsils/benchmarks`
- Commit: `0060e156826e733d69bf5b3322d1bdd0d03a1f9a`

The exact six BLIF files needed for the frozen natural evaluation and P8 train/validation root selection are embedded in `05_BENCHMARK_SOURCES/EPFL_size_blif_pinned/`.
