# Baseline and corpus references

This file records implementation/corpus targets for the benchmark protocol. Exact versions/commits must be frozen in the manifest used for confirmatory runs.

- Public CM project: https://github.com/Relative0/Correspondence_Matrices
- Published CM site: https://relative0.github.io/Correspondence_Matrices/
- Original CM paper: https://www.b-theory.com/CorrespondenceMatrices.pdf
- PolyBoRi ZDD overview: https://polybori.sourceforge.net/zdd.html
- Sage Boolean polynomial / PolyBoRi reference: https://doc.sagemath.org/html/en/reference/polynomial_rings/sage/rings/polynomial/pbori/pbori.html
- CUDD maintained repository: https://github.com/cuddorg/cudd
- mockturtle XAG optimization docs: https://mockturtle.readthedocs.io/en/stable/algorithms/xag_optimization.html
- mockturtle XAG algebraic rewriting: https://mockturtle.readthedocs.io/en/latest/algorithms/xag_algebraic_rewriting.html
- mockturtle XAG balancing: https://mockturtle.readthedocs.io/en/latest/algorithms/xag_balancing.html
- mockturtle linear resynthesis: https://mockturtle.readthedocs.io/en/latest/algorithms/linear_resynthesis.html
- egg equality saturation paper: https://arxiv.org/abs/2004.03082
- RevLib reversible benchmark library: https://www.revlib.org/
